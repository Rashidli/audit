<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <h4 class="card-title">Qruplar</h4>
                                <p>Yeni <?php echo e($mixin); ?> sifariş sayı: <?php echo e($orders_count); ?></p>
                            <br>
                            <br>

                            <div class="table-responsive">
                                <table class="table table-bordered mb-0">

                                    <thead>
                                    <tr>
                                        <th>№</th>
                                        <th>Ad</th>
                                        <th>Yeni Sifariş sayı</th>
                                        <th>İşlənmiş sifariş sayı</th>
                                        <th>Sifariş ver</th>
                                        <th>Sifariş geri al</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <th scope="row"><?php echo e($group->id); ?></th>
                                            <td><?php echo e($group->title); ?></td>
                                            <td> <a class="btn btn-primary" href="<?php echo e(route('group_orders', $group->id)); ?>">Sifarişlərinə bax</a>  <span class="btn btn-primary"><?php echo e(count($group->orders()->whereNull('auditor_status')->get())); ?></span></td>
                                            <td> <a class="btn btn-primary" href="<?php echo e(route('worked_group_orders', $group->id)); ?>">Sifarişlərinə bax</a>  <span class="btn btn-primary"><?php echo e(count($group->orders()->whereNotNull('auditor_status')->get())); ?></span></td>

                                            <td>
                                                <form action="<?php echo e(route('distributeNewOrders')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($group->id); ?>" name="group_id">
                                                    <input type="hidden" value="<?php echo e($mixin); ?>" name="mixin">
                                                    <input  type="number" required name="number">
                                                    <button class="btn btn-primary" type="submit">Sifariş ver</button>
                                                </form>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('removeOrders')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" value="<?php echo e($group->id); ?>" name="group_id">
                                                    <input type="hidden" value="<?php echo e($mixin); ?>" name="mixin">
                                                    <input  type="number" required name="number">
                                                    <button class="btn btn-primary" type="submit">Sifariş geri al</button>
                                                </form>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>



<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/orders/share_orders.blade.php ENDPATH**/ ?>