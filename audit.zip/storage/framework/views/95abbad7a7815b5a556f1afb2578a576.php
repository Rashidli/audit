<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">Hesabat</h4>

                                <form action="<?php echo e(route('report')); ?>" method="get">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class=" col-form-label">Limit</label>
                                                <select class="form-control" type="text" name="limit">
                                                    <option value="10" <?php echo e(request()->limit == 10 ? 'selected' : ''); ?>>10</option>
                                                    <option value="25" <?php echo e(request()->limit == 25 ? 'selected' : ''); ?>>25</option>
                                                    <option value="50" <?php echo e(request()->limit == 50 ? 'selected' : ''); ?>>50</option>
                                                    <option value="100" <?php echo e(request()->limit == 100 ? 'selected' : ''); ?>>100</option>
                                                    <option value="500" <?php echo e(request()->limit == 500 ? 'selected' : ''); ?>>500</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class=" col-form-label" for="group_id">Qrupu seç</label>
                                                <select class="form-control" id="group_id" type="text" name="group_id">
                                                    <option selected value="">---</option>
                                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($group->id); ?>" <?php echo e(request()->group_id == $group->id ? 'selected' : ''); ?>><?php echo e($group->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class=" col-form-label" for="auditor_title">Auditor seç</label>
                                                <select class="form-control" id="auditor_title" type="text" name="auditor_title">
                                                    <option selected value="">---</option>
                                                    <?php $__currentLoopData = $auditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auditor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($auditor->name); ?>" <?php echo e(request()->auditor_title == $auditor->name ? 'selected' : ''); ?>><?php echo e($auditor->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class=" col-form-label" for="order_status">Sifariş statusu</label>
                                                <select class="form-control" id="order_status" type="text" name="order_status">
                                                    <option selected value="">---</option>
                                                    <option value="1" <?php echo e(request()->order_status == '1' ? 'selected' : ''); ?>>Yüngül</option>
                                                    <option value="2" <?php echo e(request()->order_status == '2' ? 'selected' : ''); ?>>Orta</option>
                                                    <option value="3" <?php echo e(request()->order_status == '3' ? 'selected' : ''); ?>>Ağır</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="col-form-label" for="mixin_single">Mixin or single</label>
                                                <select class="form-control" id="mixin_single" name="mixin_single">
                                                    <option selected value="">---</option>
                                                    <option value="mixin" <?php echo e(request()->mixin_single == 'mixin' ? 'selected' : ''); ?>>Mixin</option>
                                                    <option value="single" <?php echo e(request()->mixin_single == 'single' ? 'selected' : ''); ?>>Single</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="col-form-label">Başlanğıc tarix</label>
                                                <input class="form-control" value="<?php echo e(request()->start_date); ?>" type="date" name="start_date">
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="col-form-label">Son tarix</label>
                                                <input class="form-control" value="<?php echo e(request()->end_date); ?>" type="date" name="end_date">
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="col-form-label">Text</label>
                                                <input class="form-control" value="<?php echo e(request()->text); ?>" type="text" name="text">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="col-form-label">Əməliyyat</label><br>
                                                <button value="submit" class="btn btn-primary">Axtar</button>
                                                <a class="btn btn-primary" href="<?php echo e(route('report')); ?>">Sıfırla</a>
                                                <span class="text-primary">Nəticə: <?php echo e($data['count']); ?></span>
                                            </div>
                                        </div>

                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">

                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Sifariş tarixi</th>
                                            <th>Sifariş id</th>
                                            <th>Xidmət növü</th>
                                            <th>Sifarişin bitmə tarixi</th>
                                            <th>Auditor</th>
                                            <th>Əməliyyat</th>
                                        </tr>
                                        </thead>
                                        <tbody id="results">
                                        <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <th scope="row"><?php echo e($order->order_number); ?></th>
                                                <td><?php echo e($order->order_date); ?></td>
                                                <td><?php echo e($order->order_id); ?></td>
                                                <td><?php echo e($order->service_type); ?></td>
                                                <td><?php echo e($order->order_end_date); ?></td>
                                                <td><?php echo e($order->auditor_name); ?></td>

                                                <td><a href="<?php echo e(route('report_edit',$order->id)); ?>" class="btn btn-primary" style="margin-right: 15px" >Edit</a></td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                    <br>
                                    <?php echo e($data['items']->links('vendor.pagination.bootstrap-5')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/reports/index.blade.php ENDPATH**/ ?>