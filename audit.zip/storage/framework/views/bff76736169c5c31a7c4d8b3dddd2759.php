<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <?php if(session('message')): ?>
                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <form action="#" method="post" enctype="multipart/form-data">

                <div class="card">
                    <div class="card-body">
                        <div class="row">

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sifariş nömrəsi</label>
                                    <input readonly value="<?php echo e($order->order_number); ?>" class="form-control" type="text" name="order_number">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sifariş tarixi</label>
                                    <input readonly value="<?php echo e($order->order_date); ?>" class="form-control" type="date" name="order_date">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Sifariş id</label>
                                    <input readonly value="<?php echo e($order->order_id); ?>" class="form-control" type="text" name="order_id">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Xidmət növü</label>
                                    <input readonly value="<?php echo e($order->service_type); ?>" class="form-control" type="text" name="service_type">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Telefon 2</label>
                                    <input readonly value="<?php echo e($order->phone_2); ?>" class="form-control" type="text" name="phone_2">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sifariş qeydi</label>
                                    <input readonly value="<?php echo e($order->service_note); ?>" class="form-control" type="text" name="service_note">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Zəng tarixi</label>
                                    <input readonly value="<?php echo e($order->call_date); ?>" class="form-control" type="text" name="call_date">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label"> Maşın nömrəsi</label>
                                    <input  readonly class="form-control" value="<?php echo e($order->car_number); ?>" type="text" name="car_number">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Fəhlə sayı</label>
                                    <input readonly  class="form-control" value="<?php echo e($order->worker_count); ?>" type="text" name="worker_count">
                                </div>
                            </div>


                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Usta sayı</label>
                                    <input  readonly class="form-control" value="<?php echo e($order->master_count); ?>" type="text" name="master_count">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sürücünün telefon nömrəsi</label>
                                    <input  readonly class="form-control" value="<?php echo e($order->driver_phone); ?>" type="text" name="driver_phone">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sürücünün qrup rəhbəri</label>
                                    <input  readonly class="form-control" value="<?php echo e($order->driver_group_head); ?>" type="text" name="driver_group_head">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Qaraj adı</label>
                                    <input readonly  class="form-control" type="text" value="<?php echo e($order->garage_name); ?>" name="garage_name">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Sifarişin bitmə tarixi</label>
                                    <input readonly value="<?php echo e($order->order_end_date); ?>" class="form-control" type="text" name="order_end_date">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Müştəri</label>
                                    <input readonly value="<?php echo e($order->customer_name); ?>" class="form-control" type="text" name="customer_name">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Telefon</label>
                                    <input readonly value="<?php echo e($order->phone); ?>" class="form-control" type="text" name="phone">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Korporativ</label>
                                    <input readonly value="<?php echo e($order->corporate); ?>" class="form-control" type="text" name="corporate">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Operator</label>
                                    <input readonly value="<?php echo e($order->operator); ?>" class="form-control" type="text" name="operator">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Sifarişin statusu</label>
                                    <input readonly value="<?php echo e($order->order_status); ?>" class="form-control" type="text" name="order_status">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Öz tutma</label>
                                    <input readonly value="<?php echo e($order->oz_tutma); ?>" class="form-control" type="text" name="oz_tutma">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Məbləğ</label>
                                    <input readonly value="<?php echo e($order->amount); ?>" class="form-control" type="text" name="amount">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Sürücü</label>
                                    <input readonly value="<?php echo e($order->driver); ?>" class="form-control" type="text" name="driver">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">İmtina səbəbi</label>
                                    <input readonly value="<?php echo e($order->reason_of_cancel); ?>" class="form-control" type="text" name="reason_of_cancel">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Sürücü məbləği</label>
                                    <input readonly value="<?php echo e($order->driver_amount); ?>" class="form-control" type="text" name="driver_amount">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Usta</label>
                                    <input readonly value="<?php echo e($order->master); ?>" class="form-control" type="text" name="master">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Fəhlə</label>
                                    <input readonly value="<?php echo e($order->worker); ?>" class="form-control" type="text" name="worker">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Əlavə xidmət</label>
                                    <input readonly value="<?php echo e($order->additional_service); ?>" class="form-control" type="text" name="additional_service">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Şöbə</label>
                                    <input readonly value="<?php echo e($order->department); ?>" class="form-control" type="text" name="department">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Məmnuniyyət statusu</label>
                                    <input readonly value="<?php echo e($order->satisfaction_status); ?>" class="form-control" type="text" name="satisfaction_status">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Ünvan</label>
                                    <input readonly value="<?php echo e($order->address); ?>" class="form-control" type="text" name="address">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Danışıq müddəti(san)</label>
                                    <input readonly value="<?php echo e($order->speaking_duration); ?>" class="form-control" type="text" name="speaking_duration">
                                </div>
                            </div>

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Qeyd</label>
                                    <input readonly value="<?php echo e($order->note); ?>" class="form-control" type="text" name="note">
                                </div>
                            </div>


                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Auditor</label>
                                    <input readonly value="<?php echo e($order->auditor_name); ?>" class="form-control" type="text" >
                                </div>
                            </div>
                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Ustaları seç</label>
                                    <select class="js-example-basic-multiple" style="width: 100%" name="masters[]" multiple="multiple">

                                        <?php $__currentLoopData = $masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($master->id); ?>" <?php $__currentLoopData = $order->masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($order_master->id == $master->id ? 'selected' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($master->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>
                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class=" col-form-label">Köməkçiləri seç</label>
                                    <select class="js-example-basic-multiple" style="width: 100%" name="workers[]" multiple="multiple">
                                        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($worker->id); ?>"   <?php $__currentLoopData = $order->workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($order_worker->id == $worker->id ? 'selected' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($worker->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>

                        </div>
                        <br><br>
                        <div class="row">
                            <nav>
                                <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                    <?php $__currentLoopData = $question_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="nav-item nav-link mb-3 <?php echo e($key == 0 ? 'active' : ''); ?>" id="nav-<?php echo e($question_cat->id); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($question_cat->id); ?>" role="tab" aria-controls="nav-<?php echo e($question_cat->id); ?>" aria-checked="true"><?php echo e($question_cat->title); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </nav>
                            <br><br>
                            <br>
                            <div class="tab-content mb-3" id="nav-tabContent">
                                <?php $__currentLoopData = $question_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-pane fade  <?php echo e($key == 0 ? 'show active' : ''); ?>" id="nav-<?php echo e($question_cat->id); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($question_cat->id); ?>-tab">
                                        <div class="row">
                                            <?php $__currentLoopData = $question_cat->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $order->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($question->id == $q->id): ?>
                                                        <div class="col-2 col-md-6 col-lg-4">
                                                            <div class="mb-3">
                                                                <div class="radio-icon-container">

                                                                    <input type="radio" name="answers[<?php echo e($question->id); ?>]" class="radio_button" value="1" <?php $__currentLoopData = $order->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($question->id == $q->id): ?> <?php echo e($q->pivot->answer == '1' ? 'checked' : ''); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> >
                                                                    <input type="radio" name="answers[<?php echo e($question->id); ?>]" class="radio_button" value="0" <?php $__currentLoopData = $order->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($question->id == $q->id): ?> <?php echo e($q->pivot->answer == '0' ? 'checked' : ''); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> >

                                                                    <label for="option1" class="radio-label">
                                                                        <i class="fas fa-check clicked_jquery_check <?php $__currentLoopData = $order->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($question->id == $q->id): ?> <?php echo e($q->pivot->answer == '1' ? 'checked' : ''); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  "></i>
                                                                        <i class="fas fa-times clicked_jquery_uncheck  <?php $__currentLoopData = $order->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($question->id == $q->id): ?> <?php echo e($q->pivot->answer == '0' ? 'checked' : ''); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></i>
                                                                        <?php echo e($question->title); ?>

                                                                    </label>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-2 col-md-4 col-lg-3">
                                <div class="mb-3">
                                    <label class="col-form-label">Auditor qeyd</label>
                                    <textarea readonly style="width: 100%"  class="form-control" type="text" name="auditor_note"><?php echo e($order->auditor_note); ?></textarea>
                                </div>
                            </div>
                            <?php if($order->images): ?>
                                <div class="col-2 col-md-4 col-lg-3">
                                    <div class="mb-3">
                                        <?php $__currentLoopData = $order->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(asset('storage/' . $image->file)); ?>" target="_blank"><img style="width: 100px; height: 100px" src="<?php echo e(asset('storage/' . $image->file)); ?>" alt=""></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/reports/edit.blade.php ENDPATH**/ ?>