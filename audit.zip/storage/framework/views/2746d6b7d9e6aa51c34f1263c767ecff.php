<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                                <?php endif; ?>
                                    <form id="fileUploadForm" method="POST" action="<?php echo e(route('insert_excel')); ?>" enctype="multipart/form-data" >
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-4">

                                                <div class="mb-3">
                                                    <label class=" col-form-label">Fayl</label>
                                                    <input id="fileInput" class="form-control" type="file" name="excel_file">

                                                </div>

                                                <div class="progress_display form-group">
                                                    <div class="progress">
                                                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
                                                    </div>
                                                </div>

                                                <div id="successMessage" class="progress_success alert alert-success">File yükləndi.</div>

                                                <div class="mb-3">
                                                    <button type="submit" class="btn progress_button btn-primary">Import et</button>
                                                </div>

                                            </div>
                                        </div>
                                    </form>
                                <h4 class="card-title">Sifarişlər</h4>
                                <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">+</a><br><br>
                                <a href="<?php echo e(route('share_orders', 'mixin')); ?>" class="btn btn-primary">Mixin sifarişləri paylaşdır(yeni) <?php echo e($mixin_count); ?></a><br><br>
                                <a href="<?php echo e(route('share_orders', 'single')); ?>" class="btn btn-primary">Single sifarişləri paylaşdır(yeni) <?php echo e($single_count); ?></a>

                                <br>
                                <br>

                                    <?php echo $__env->make('includes.search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <div class="table-responsive">
                                    <table class="table table-bordered mb-0">

                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Sifariş tarixi</th>
                                            <th>Sifariş id</th>
                                            <th>Xidmət növü</th>
                                            <th>Sifarişin bitmə tarixi</th>
                                            <th>Auditor</th>
                                            <th>Əməliyyat</th>
                                        </tr>
                                        </thead>
                                        <tbody id="results">
                                        <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($order->order_number); ?></th>
                                                <td><?php echo e($order->order_date); ?></td>
                                                <td><?php echo e($order->order_id); ?></td>
                                                <td><?php echo e($order->service_type); ?></td>
                                                <td><?php echo e($order->order_end_date); ?></td>
                                                <td><?php echo e($order->auditor_name); ?></td>

                                                <td><a href="<?php echo e(route('orders.edit',$order->id)); ?>" class="btn btn-primary" style="margin-right: 15px" >Edit</a>
                                                    <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="post" style="display: inline-block">
                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <?php echo csrf_field(); ?>
                                                        <button  type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                    <br>
                                    <?php echo e($data['items']->links('vendor.pagination.bootstrap-5')); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>



<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/orders/index.blade.php ENDPATH**/ ?>