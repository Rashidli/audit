<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="card-title">İstifadəçi əlavə et</h4>
                                <form action="<?php echo e(route('users.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="example-email-input" class="col-form-label">Email</label>
                                        <input class="form-control" type="email" name="email" id="example-email-input">
                                        <?php if($errors->first('email')): ?> <small class="form-text text-danger"><?php echo e($errors->first('email')); ?></small> <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="example-text-input" class=" col-form-label">Username</label>
                                        <input class="form-control" type="text" name="name"  id="example-text-input">
                                        <?php if($errors->first('name')): ?> <small class="form-text text-danger"><?php echo e($errors->first('name')); ?></small> <?php endif; ?>
                                    </div>

                                    <!-- end row -->
                                    <div class="mb-3">
                                        <label for="example-search-input" class="col-form-label">Password</label>
                                        <input class="form-control" type="password" name="password" id="example-search-input">
                                        <?php if($errors->first('password')): ?> <small class="form-text text-danger"><?php echo e($errors->first('password')); ?></small> <?php endif; ?>
                                    </div>


                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <input id="<?php echo e($role->id); ?>" type="radio" name="role" value="<?php echo e($role->name); ?>">
                                        <label for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label><br>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    <div class="mb-3">
                                        <button class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/users/create.blade.php ENDPATH**/ ?>