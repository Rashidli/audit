<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <?php if(session('message')): ?>
                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
                <form action="<?php echo e(route('questions.update', $question->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Sual editlə</h4>
                            <div class="row">
                                <div class="col-6">

                                    <div class="mb-3">
                                        <label class="col-form-label">Sual</label>
                                        <input value="<?php echo e($question->title); ?>" class="form-control" type="text" name="title">
                                        <?php if($errors->first('title')): ?> <small class="form-text text-danger"><?php echo e($errors->first('title')); ?></small> <?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                        <label class="col-form-label">Kateqoriya</label>
                                        <select class="form-control" type="text" name="question_cat_id">
                                            <option selected disabled>----- </option>
                                            <?php $__currentLoopData = $question_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->id); ?>" <?php echo e($question->question_cat_id == $c->id ? 'selected' : ''); ?>><?php echo e($c->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->first('question_cat_id')): ?> <small class="form-text text-danger"><?php echo e($errors->first('question_cat_id')); ?></small> <?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                        <label class="col-form-label">Dərəcə</label>
                                        <select class="form-control" type="text" name="level">
                                            <option selected disabled>----- </option>

                                            <option value="1" <?php echo e($question->level == 1 ? 'selected' : ''); ?>>Yüngül</option>
                                            <option value="2" <?php echo e($question->level == 2 ? 'selected' : ''); ?>>Orta</option>
                                            <option value="3" <?php echo e($question->level == 3 ? 'selected' : ''); ?>>Ağır</option>

                                        </select>
                                        <?php if($errors->first('level')): ?> <small class="form-text text-danger"><?php echo e($errors->first('level')); ?></small> <?php endif; ?>
                                    </div>



                                    <div class="mb-3">
                                        <button class="btn btn-primary">Yadda saxla</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </form>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/questions/edit.blade.php ENDPATH**/ ?>