<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-4">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <h4 class="card-title">Auditor editlə</h4>
                            <form action="<?php echo e(route('auditors.update',$auditor->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="mb-3">
                                    <label for="example-email-input" class="col-form-label">Email</label>
                                    <input class="form-control" value="<?php echo e($auditor->email); ?>" type="email" name="email" id="example-email-input">
                                    <?php if($errors->first('email')): ?> <small class="form-text text-danger"><?php echo e($errors->first('email')); ?></small> <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label for="example-text-input" class=" col-form-label">Username</label>
                                    <input class="form-control" value="<?php echo e($auditor->name); ?>" type="text" name="name"  id="example-text-input">
                                    <?php if($errors->first('name')): ?> <small class="form-text text-danger"><?php echo e($errors->first('name')); ?></small> <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <label for="example-search-input" class="col-form-label">Password</label>
                                    <input class="form-control" type="password" name="password" id="example-search-input">
                                    <?php if($errors->first('password')): ?> <small class="form-text text-danger"><?php echo e($errors->first('password')); ?></small> <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label class="col-form-label">Qrupun seçin</label>
                                    <select class="form-control" type="text" name="group_id">
                                        <option selected disabled>--seçin--</option>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($group->id); ?>" <?php echo e($group->id == $auditor->group_id ? 'selected' : ''); ?>><?php echo e($group->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->first('group_id')): ?> <small class="form-text text-danger"><?php echo e($errors->first('group_id')); ?></small> <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <h4>Roles</h4>
                                    <?php if($auditor->roles): ?>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <input id="<?php echo e($role->id); ?>" type="radio" name="role" <?php $__currentLoopData = $auditor->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($p->name == $role->name ? 'checked' : ''); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($role->name); ?>">
                                            <label for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label><br>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </div>
                                <div class="mb-3">
                                    <button class="btn btn-primary">Submit</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/auditors/edit.blade.php ENDPATH**/ ?>