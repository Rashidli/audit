<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Permission əlavə et</h4>
                                <form action="<?php echo e(route('permissions.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="example-email-input" class="col-form-label">Name</label>
                                        <input class="form-control" type="text" name="name" id="example-email-input">
                                        <?php if($errors->first('name')): ?> <small class="form-text text-danger"><?php echo e($errors->first('name')); ?></small> <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="example-email-input" class="col-form-label">Group name</label>
                                        <input class="form-control" type="text" name="group_name" id="example-email-input">
                                        <?php if($errors->first('group_name')): ?> <small class="form-text text-danger"><?php echo e($errors->first('group_name')); ?></small> <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <button class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/permissions/create.blade.php ENDPATH**/ ?>