<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>

                            <h4 class="card-title">Sifarişlər</h4>

                            <form action="<?php echo e(route($route, $group->id)); ?>" method="get">
                                <div class="row">
                                    <div class="col-3 col-md-3">
                                        <div class="mb-3">
                                            <label class=" col-form-label">Limit</label>
                                            <select class="form-control" type="text" name="limit">
                                                <option value="10" <?php echo e(request()->limit == 10 ? 'selected' : ''); ?>>10</option>
                                                <option value="25" <?php echo e(request()->limit == 25 ? 'selected' : ''); ?>>25</option>
                                                <option value="50" <?php echo e(request()->limit == 50 ? 'selected' : ''); ?>>50</option>
                                                <option value="100" <?php echo e(request()->limit == 100 ? 'selected' : ''); ?>>100</option>
                                                <option value="500" <?php echo e(request()->limit == 500 ? 'selected' : ''); ?>>500</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3 col-md-3">
                                        <div class="mb-3">
                                            <label class="col-form-label">Sifariş id görə</label>
                                            <input class="form-control" value="<?php echo e(request()->text); ?>" id="text" type="text" name="text">
                                        </div>
                                    </div>
                                    <div class="col-1 col-md-3">
                                        <div class="mb-3">
                                            <div class="pt-4 mt-3">
                                                <button value="submit" class="btn btn-primary">Axtar</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-2 col-md-3">
                                        <div class="mb-3" style="display: flex; justify-content: space-between">
                                            <div class="pt-4 mt-3">
                                                <a class="btn btn-primary" href="<?php echo e(route($route, $group->id)); ?>">Sıfırla</a>
                                            </div>
                                            <div class="pt-4 mt-3">
                                                <p class="text-primary">Nəticə: <?php echo e($count); ?></p>
                                            </div>
                                        </div>



                                    </div>
                                </div>
                            </form>

                            <div class="table-responsive">
                                <table class="table table-bordered mb-0">

                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Sifariş tarixi</th>
                                        <th>Sifariş id</th>
                                        <th>Ünvan</th>
                                        <th>Sürücü</th>
                                        <th>Sifarişin bitmə tarixi</th>
                                        <th>Müştəri</th>
                                        <th>Əməliyyat</th>
                                    </tr>
                                    </thead>
                                    <tbody id="results">
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($order->order_number); ?></th>
                                            <td><?php echo e($order->order_date); ?></td>
                                            <td><?php echo e($order->order_id); ?></td>
                                            <td><?php echo e($order->address); ?></td>
                                            <td><?php echo e($order->driver); ?></td>
                                            <td><?php echo e($order->order_end_date); ?></td>
                                            <td><?php echo e($order->customer_name); ?></td>

                                            <td>
                                                <a href="<?php echo e(route('auditor_orders_edit',$order->id)); ?>" class="btn btn-primary" style="margin-right: 15px" >Edit</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <br>
                                <?php echo e($orders->links('vendor.pagination.bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/group_orders/index.blade.php ENDPATH**/ ?>