<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                                <?php endif; ?>
                                <h4 class="card-title">Suallar</h4>
                                <a href="<?php echo e(route('questions.create')); ?>" class="btn btn-primary">+</a>
                                <br>
                                <br>
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">

                                        <thead>
                                        <tr>
                                            <th>№</th>
                                            <th>Sual</th>
                                            <th>Dərəcəsi</th>
                                            <th>Kateqoriya</th>
                                            <th>Əməliyyat</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <th scope="row"><?php echo e($question->id); ?></th>
                                                <td><?php echo e($question->title); ?></td>
                                                <td>
                                                    <?php if($question->level == 1): ?>
                                                        Yüngül
                                                    <?php elseif($question->level == 2): ?>
                                                        Orta
                                                    <?php elseif($question->level == 3): ?>
                                                        Ağır
                                                    <?php elseif($question->level == 4): ?>
                                                        Orta/Ağır
                                                    <?php elseif($question->level == 5): ?>
                                                        Kateqoriyasız
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($question->question_cat->title); ?></td>
                                                <td><a href="<?php echo e(route('questions.edit',$question->id)); ?>" class="btn btn-primary" style="margin-right: 15px" >Edit</a>
                                                    <form action="<?php echo e(route('questions.destroy', $question->id)); ?>" method="post" style="display: inline-block">
                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>



<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/questions/index.blade.php ENDPATH**/ ?>