<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-4">
                    <div class="card">
                        <div class="card-body">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                            <?php endif; ?>
                            <h4 class="card-title">Role editlə</h4>

                            <form action="<?php echo e(route('roles.update',$role->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="mb-3">
                                    <label for="example-email-input" class="col-form-label">Name</label>
                                    <input class="form-control" value="<?php echo e($role->name); ?>" type="text" name="name" id="example-email-input">
                                    <?php if($errors->first('name')): ?> <small class="form-text text-danger"><?php echo e($errors->first('name')); ?></small> <?php endif; ?>
                                </div>
                                <div class="mb-3">
                                    <h4>Permissions</h4>

                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($key % 4 == 0): ?>
                                            <br>
                                            <input id="<?php echo e($permission->group_name); ?>" class="group-checkbox" data-group="<?php echo e($permission->group_name); ?>"  type="checkbox">
                                            <label style="font-weight: 600" for="<?php echo e($permission->group_name); ?>"><?php echo e($permission->group_name); ?></label> <br><br>
                                        <?php endif; ?>
                                        <input id="<?php echo e($permission->id); ?>" type="checkbox"  data-group="<?php echo e($permission->group_name); ?>" name="permission[]" <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($p->name == $permission->name ? 'checked' : ''); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($permission->name); ?>">
                                        <label for="<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label><br>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                                <div class="mb-3">
                                    <button class="btn btn-primary">Submit</button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\Togrul Memmedov\Desktop\audit\resources\views/roles/edit.blade.php ENDPATH**/ ?>